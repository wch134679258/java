// 表单全部逻辑：模式切换、校验、密码强度、提交状态机
// 纯逻辑，不触碰 DOM（聚焦/高度同步等交由组件处理）
import { reactive, ref, computed, onBeforeUnmount } from 'vue'
import { sendAuthCode, registerUser, loginUser, USE_MOCK } from '../api/auth'

const COPY = {
  login:  { t: '欢迎回来', s: '登录后继续你的探索之旅', b: '登 录' },
  signup: { t: '创建账号', s: '加入我们，开启星海之旅', b: '注 册' },
  reset:  { t: '重置密码', s: '输入邮箱，我们会发送重置链接', b: '发送链接' }
}

const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/

export function useAuthForm (emit) {
  const mode = ref('login')
  const form = reactive({ name: '', email: '', pass: '', pass2: '', code: '' })
  const remember = ref(true)
  const agree = ref(false)
  const agreeInvalid = ref(false)
  const invalid = reactive({ name: false, email: false, pass: false, pass2: false, code: false })
  const showPass = reactive({ pass: false, pass2: false })
  const submitState = ref('idle')
  const formError = ref('')        // 提交级错误（接口失败等）

  const headSwap = ref(false)
  const headTitle = ref(COPY.login.t)
  const headSub = ref(COPY.login.s)
  const submitText = ref(COPY.login.b)

  const strength = reactive({ width: '0', color: '', label: '密码强度：—' })

  // ===== 验证码（邮箱验证码，已预留后端接口）=====
  const codeCountdown = ref(0)      // 倒计时（秒）
  const codeSent = ref(false)       // 是否已发送
  const codeSending = ref(false)    // 请求发送中
  const devCode = ref('')           // 演示模式下的验证码（真实环境由后端发送，前端不保存明文）
  const codeError = ref('')         // 验证码字段的报错文案
  const codeHint = ref('')          // 已发送提示
  let codeTimer = null
  const codeBtnText = computed(() => {
    if (codeSending.value) return '发送中…'
    if (codeCountdown.value > 0) return codeCountdown.value + 's 后重试'
    return '获取验证码'
  })

  function stopCodeTimer () {
    if (codeTimer) { clearInterval(codeTimer); codeTimer = null }
  }

  // 发送验证码：先校验邮箱，再调用后端接口（POST /api/auth/send-code）。
  // 演示模式（USE_MOCK=true）下由前端生成验证码以便测试；真实环境请置为 false。
  async function sendCode () {
    if (codeCountdown.value > 0 || codeSending.value) return
    if (!RE_EMAIL.test(form.email.trim())) {
      invalid.email = true
      return
    }
    codeSending.value = true
    codeError.value = ''
    try {
      const res = await sendAuthCode({ email: form.email.trim() })
      codeSent.value = true
      if (USE_MOCK && res.devCode) devCode.value = res.devCode
      const expMin = res.expiresIn ? Math.round(res.expiresIn / 60) : 5
      codeHint.value = `验证码已发送至 ${form.email.trim()}，请在 ${expMin} 分钟内输入`
        + (USE_MOCK && res.devCode ? `（演示码：${res.devCode}）` : '')
      stopCodeTimer()
      codeCountdown.value = 60
      codeTimer = setInterval(() => {
        codeCountdown.value--
        if (codeCountdown.value <= 0) stopCodeTimer()
      }, 1000)
    } catch (e) {
      codeError.value = (e && e.message) || '验证码发送失败，请稍后重试'
    } finally {
      codeSending.value = false
    }
  }

  function clearField (k) {
    invalid[k] = false
    if (k === 'code') codeError.value = ''
  }
  function clearErrors () {
    invalid.name = invalid.email = invalid.pass = invalid.pass2 = false
    agreeInvalid.value = false
  }

  function tabOn (m) {
    return m === mode.value || (mode.value === 'reset' && m === 'login')
  }

  function setMode (next) {
    if (next === mode.value) return
    mode.value = next
    headSwap.value = true
    setTimeout(() => {
      headTitle.value = COPY[mode.value].t
      headSub.value = COPY[mode.value].s
      submitText.value = COPY[mode.value].b
      headSwap.value = false
    }, 200)
    clearErrors()
  }

  function togglePass (k) { showPass[k] = !showPass[k] }

  function onPassInput () {
    clearField('pass')
    const v = form.pass
    let score = 0
    if (v.length >= 8) score++
    if (/[A-Za-z]/.test(v) && /\d/.test(v)) score++
    if (v.length >= 12) score++
    if (/[^A-Za-z0-9]/.test(v)) score++
    const pct = [0, 30, 58, 80, 100][score]
    const label = ['弱', '一般', '不错', '很强', '极强'][Math.min(score, 4)]
    strength.width = pct + '%'
    strength.color = score <= 1
      ? 'linear-gradient(90deg,#ff5f78,#ff8a5f)'
      : score === 2
        ? 'linear-gradient(90deg,#fbbf24,#f59e0b)'
        : 'linear-gradient(90deg,#22d3ee,#7c5cff)'
    strength.label = v ? '密码强度：' + label : '密码强度：—'
  }

  function validate () {
    clearErrors()
    let ok = true
    let first = null
    if (!RE_EMAIL.test(form.email.trim())) { invalid.email = true; ok = false; first = first || 'email' }
    if (mode.value === 'signup') {
      if (form.name.trim().length < 2) { invalid.name = true; ok = false; first = first || 'name' }
      if (!(form.pass.length >= 8 && /[A-Za-z]/.test(form.pass) && /\d/.test(form.pass))) { invalid.pass = true; ok = false; first = first || 'pass' }
      if (form.pass2 !== form.pass || !form.pass2) { invalid.pass2 = true; ok = false; first = first || 'pass2' }
      if (!form.code.trim()) { invalid.code = true; codeError.value = codeSent.value ? '请输入验证码' : '请先获取验证码'; ok = false; first = first || 'code' }
      else if (USE_MOCK && form.code.trim() !== devCode.value) { invalid.code = true; codeError.value = '验证码不正确'; ok = false; first = first || 'code' }
      if (!agree.value) { ok = false; agreeInvalid.value = true }
    }
    if (mode.value === 'login') {
      if (form.pass.length < 6) { invalid.pass = true; ok = false; first = first || 'pass' }
    }
    return { ok, first }
  }

  // 客户端校验（同步）：返回 { ok, first } 供组件聚焦首个错误项
  function onSubmit () {
    const { ok, first } = validate()
    if (!ok) return { ok, first }
    runSubmit()
    return { ok: true }
  }

  // 提交：调用后端接口（注册 / 登录 / 重置），处理 loading / done / 错误
  async function runSubmit () {
    submitState.value = 'loading'
    formError.value = ''
    try {
      if (mode.value === 'signup') {
        await registerUser({
          name: form.name.trim(),
          email: form.email.trim(),
          password: form.pass,
          code: form.code.trim()
        })
      } else if (mode.value === 'login') {
        await loginUser({
          email: form.email.trim(),
          password: form.pass,
          remember: remember.value
        })
      } else {
        // reset：真实环境调用 POST /api/auth/reset
        await new Promise((r) => setTimeout(r, 1000))
      }
      submitState.value = 'done'
      setTimeout(() => {
        submitState.value = 'idle'
        emit('success', mode.value)
      }, 480)
    } catch (e) {
      submitState.value = 'idle'
      formError.value = (e && e.message) || '操作失败，请稍后再试'
    }
  }

  function resetToLogin () {
    form.name = ''
    form.email = ''
    form.pass = ''
    form.pass2 = ''
    form.code = ''
    agree.value = false
    remember.value = true
    agreeInvalid.value = false
    clearErrors()
    invalid.code = false
    codeError.value = ''
    codeHint.value = ''
    codeSent.value = false
    codeCountdown.value = 0
    codeSending.value = false
    formError.value = ''
    stopCodeTimer()
    strength.width = '0'
    strength.color = ''
    strength.label = '密码强度：—'
    showPass.pass = false
    showPass.pass2 = false
    setMode('login')
  }

  onBeforeUnmount(stopCodeTimer)

  return {
    mode, form, remember, agree, agreeInvalid, invalid, showPass, submitState, formError,
    headSwap, headTitle, headSub, submitText, strength,
    codeCountdown, codeSent, codeSending, codeError, codeHint, codeBtnText, devCode,
    clearField, clearErrors, tabOn, setMode, togglePass, onPassInput,
    validate, onSubmit, sendCode, stopCodeTimer, resetToLogin
  }
}
