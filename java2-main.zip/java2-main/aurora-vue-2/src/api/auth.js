// ============================================================
//  认证后端接口（预留 / 对接用）
// ------------------------------------------------------------
//  真实环境对接步骤：
//    1. 将下方 USE_MOCK 改为 false
//    2. 后端需提供以下接口（BASE 默认 "/api"，可用 .env 的
//       VITE_API_BASE 覆盖，例如 https://api.example.com）：
//
//    POST /api/auth/send-code
//      入参: { email: string }
//      返回: { code: "OK", expiresIn: 300 }   // expiresIn 单位：秒
//      * 真实环境验证码通过邮件下发，前端【不】返回明文
//
//    POST /api/auth/register
//      入参: { name, email, password, code }
//      返回: { token: string, userId: string }
//
//    POST /api/auth/login
//      入参: { email, password, remember }
//      返回: { token: string, userId: string }
//
//    3. 错误约定：HTTP 非 2xx 时，响应体 { message: "错误说明" }
//       会被提取为抛出的 Error.message，直接展示在表单错误横幅。
// ============================================================

const USE_MOCK = true
const BASE = (import.meta.env && import.meta.env.VITE_API_BASE) || '/api'

async function request (path, body) {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
  if (!res.ok) {
    let message = '请求失败，请稍后再试'
    try {
      const data = await res.json()
      if (data && data.message) message = data.message
    } catch (_) { /* 忽略解析错误 */ }
    throw new Error(message)
  }
  return res.json()
}

// 发送验证码（邮箱）
export async function sendAuthCode ({ email }) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 600))
    // 演示模式：直接返回明文验证码，方便前端测试
    return {
      code: 'OK',
      expiresIn: 300,
      devCode: String(Math.floor(100000 + Math.random() * 900000))
    }
  }
  return request('/auth/send-code', { email })
}

// 注册
export async function registerUser (payload) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 1400))
    return { token: 'mock-token', userId: 'u_' + Date.now() }
  }
  return request('/auth/register', payload)
}

// 登录
export async function loginUser (payload) {
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 900))
    return { token: 'mock-token', userId: 'u_' + Date.now() }
  }
  return request('/auth/login', payload)
}

export { USE_MOCK, BASE }
