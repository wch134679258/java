package com.fanren;

import com.fanren.model.Chapter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 纯文本小说导入器（零依赖）。
 *
 * 用法：把你拥有合法版权的《凡人修仙传》文本保存为 data/fanren.txt，
 * 每一章以「第N章 标题」开头（N 可为阿拉伯数字或中文数字），
 * 例如：
 *     第1章 山路弯弯
 *     正文第一段……
 *     正文第二段……
 *     第2章 青牛镇
 *     ……
 * 服务启动时会自动解析并按章节入库，覆盖内置的占位示例。
 *
 * 说明：本导入器只负责“按行切分”，不爬取、不存储任何受版权保护的原文；
 * 文本由使用者自行提供（如个人已购电子书/正版导出），请确保你拥有相应权利。
 */
public final class TxtImporter {

    // 匹配章节标题行，例如「第1章 山路弯弯」「第 十二 章 XXX」
    private static final Pattern HEAD =
            Pattern.compile("^\\s*第\\s*([0-9零一二三四五六七八九十百千]+)\\s*章\\s*(.*)$");

    private TxtImporter() { }

    public static List<Chapter> parse(File file, String bookId) {
        List<Chapter> list = new ArrayList<>();
        if (file == null || !file.exists()) return list;

        int index = 0;
        String currentTitle = "前言";
        StringBuilder buffer = new StringBuilder();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                Matcher m = HEAD.matcher(line);
                if (m.find()) {
                    // 遇到新章节标题：先把上一章存起来
                    flush(list, bookId, index, currentTitle, buffer);
                    index++;
                    String t = m.group(2).trim();
                    currentTitle = t.isEmpty() ? ("第" + m.group(1) + "章") : t;
                    buffer = new StringBuilder();
                } else if (!line.trim().isEmpty()) {
                    buffer.append(line).append("\n");
                }
            }
            flush(list, bookId, index, currentTitle, buffer); // 收尾最后一章
        } catch (IOException e) {
            System.err.println("[TxtImporter] 读取失败: " + e.getMessage());
        }
        return list;
    }

    private static void flush(List<Chapter> list, String bookId, int index,
                              String title, StringBuilder buffer) {
        if (buffer.length() == 0) return;
        String id = bookId + "-" + index;
        list.add(new Chapter(id, bookId, index, title, buffer.toString().trim()));
    }
}
