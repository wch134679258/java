package com.fanren;

/**
 * 统一异常：携带 HTTP 状态码与提示信息。
 * 在 Controller 层（DataStore）抛出，由 ApiHandler 统一捕获并写回响应。
 */
public class HttpError extends RuntimeException {

    private final int status;

    public HttpError(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
