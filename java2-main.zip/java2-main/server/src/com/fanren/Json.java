package com.fanren;

/**
 * 极简 JSON 工具：仅做字符串转义与数组拼接，零外部依赖。
 * 因为本项目不引入任何第三方库（如 fastjson / jackson），
 * 且返回的数据结构固定，手写一个够用的小工具即可，也方便学习。
 */
public final class Json {

    private Json() { }

    /** 把字符串转成合法的 JSON 字符串字面量（含两端引号，自动转义特殊字符）。 */
    public static String str(String s) {
        if (s == null) return "\"\"";
        StringBuilder b = new StringBuilder();
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n");  break;
                case '\r': b.append("\\r");  break;
                case '\t': b.append("\\t");  break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        b.append('"');
        return b.toString();
    }

    /** 把一组 JSON 片段拼成一个 JSON 数组字符串。 */
    public static String arr(java.util.List<String> items) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) b.append(',');
            b.append(items.get(i));
        }
        b.append(']');
        return b.toString();
    }
}
