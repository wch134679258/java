package com.fanren;

import com.fanren.store.DataStore;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * 请求处理器：负责路由分发、CORS、统一异常处理。
 * 真正的业务逻辑（取数据、拼 JSON）都在 DataStore 里。
 */
public class ApiHandler implements HttpHandler {

    private final DataStore store;

    public ApiHandler(DataStore store) {
        this.store = store;
    }

    @Override
    public void handle(HttpExchange ex) throws IOException {
        // 1) 跨域头（前端跑在 5174，后端跑在 8080，必须放行）
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

        // 2) 预检请求直接放行
        if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return;
        }

        try {
            URI uri = ex.getRequestURI();
            String path = uri.getPath();                 // 例如 /api/books
            if (path.startsWith("/api")) path = path.substring(4);
            if (path.isEmpty()) path = "/";
            Map<String, String> params = parseQuery(uri.getRawQuery());

            String body = route(ex.getRequestMethod(), path, params);
            sendJson(ex, 200, body);
        } catch (HttpError e) {
            sendJson(ex, e.getStatus(), "{\"error\":" + Json.str(e.getMessage()) + "}");
        } catch (Exception e) {
            sendJson(ex, 500, "{\"error\":" + Json.str("服务器内部错误: " + e.getMessage()) + "}");
        } finally {
            ex.close();
        }
    }

    /** 根据 method + path 分发到对应逻辑。 */
    private String route(String method, String path, Map<String, String> params) {
        if (!"GET".equalsIgnoreCase(method)) {
            throw new HttpError(405, "仅支持 GET 请求");
        }
        if ("/health".equals(path)) {
            return "{\"status\":\"ok\"}";
        }
        if ("/books".equals(path)) {
            return store.booksJson();
        }
        if (path.startsWith("/books/")) {
            String[] parts = path.substring("/books/".length()).split("/");
            String bookId = parts[0];
            if (parts.length == 1) {
                return store.bookDetailJson(bookId, params);     // /books/{id}
            }
            if (parts.length == 2 && "chapters".equals(parts[1])) {
                return store.chaptersJson(bookId, params);       // /books/{id}/chapters
            }
        }
        if (path.startsWith("/chapters/")) {
            String id = path.substring("/chapters/".length());
            if (!id.isEmpty()) {
                return store.chapterDetailJson(id);               // /chapters/{id}
            }
        }
        if ("/search".equals(path)) {
            return store.searchJson(params);                     // /search?q=xxx&bookId=
        }
        throw new HttpError(404, "接口不存在: " + path);
    }

    /** 解析查询字符串 ?a=1&b=2 为 Map。 */
    private Map<String, String> parseQuery(String raw) {
        Map<String, String> map = new HashMap<>();
        if (raw == null || raw.isEmpty()) return map;
        for (String pair : raw.split("&")) {
            String[] kv = pair.split("=", 2);
            String key = decode(kv[0]);
            String val = kv.length > 1 ? decode(kv[1]) : "";
            map.put(key, val);
        }
        return map;
    }

    private static String decode(String s) {
        try { return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8); } catch (Exception e) { return s; }
    }

    private void sendJson(HttpExchange ex, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }
}
