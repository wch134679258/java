package com.fanren.store;

import com.fanren.HttpError;
import com.fanren.Json;
import com.fanren.TxtImporter;
import com.fanren.model.Book;
import com.fanren.model.Chapter;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据存储层（内存版）。
 *
 * 启动时：先装入内置占位示例数据，再尝试导入 data/fanren.txt（若存在则覆盖示例）。
 * 这是“java 学习”项目，故意不接数据库；若以后要持久化，把这里换成 JDBC / JPA 即可。
 */
public class DataStore {

    private final Map<String, Book> books = new LinkedHashMap<>();
    private final Map<String, Chapter> chaptersById = new LinkedHashMap<>();
    private final List<Chapter> order = new ArrayList<>();   // 保持章节顺序，用于上/下章与分页

    private DataStore() { }

    public static DataStore build(String dataFile) {
        DataStore ds = new DataStore();
        ds.loadSample();              // 内置占位示例
        ds.tryImportTxt(dataFile);    // 用户提供的正版文本（可选）
        return ds;
    }

    // ---------------------- 写入 ----------------------

    public void addBook(Book b) {
        books.put(b.id, b);
    }

    public void addChapter(Chapter c) {
        chaptersById.put(c.id, c);
        order.add(c);
    }

    private void loadSample() {
        Book b = new Book("fanren", "凡人修仙传", "忘语",
                "《凡人修仙传》是忘语创作的古典仙侠小说。本服务仅作“在线阅读框架”演示，" +
                "内置章节为占位示例。请将你拥有合法版权的文本保存为 data/fanren.txt 后重启服务即可导入。",
                "📖");
        addBook(b);

        String[] titles = {
                "第一章 示例：山边小村",
                "第二章 示例：初闻仙道",
                "第三章 示例：意外之缘"
        };
        // 占位正文：明确标注“非原文”，避免任何版权内容混入
        String placeholder = """
                （这是占位示例内容，并非小说原文。请把你拥有合法版权的《凡人修仙传》文本
                保存为 data/fanren.txt，按“第N章 标题”分段，重启服务即可自动导入。）

                韩立站在山崖边，望着远处起伏的群山，心里盘算着接下来的打算……（示例段落，可替换）""";
        for (int i = 0; i < titles.length; i++) {
            addChapter(new Chapter("fanren-" + (i + 1), "fanren", i + 1, titles[i], placeholder));
        }
        b.chapterCount = order.size();
    }

    private void tryImportTxt(String file) {
        File f = new File(file);
        if (!f.exists()) {
            System.out.println("[init] 未找到 " + file + "，使用内置占位示例数据。");
            return;
        }
        List<Chapter> imported = TxtImporter.parse(f, "fanren");
        if (imported.isEmpty()) {
            System.out.println("[init] " + file + " 未解析出任何章节，仍使用内置示例。");
            return;
        }
        // 用导入的章节替换示例章节
        chaptersById.clear();
        order.clear();
        for (Chapter c : imported) addChapter(c);
        Book b = books.get("fanren");
        if (b != null) b.chapterCount = order.size();
        System.out.println("[init] 已从 " + file + " 导入 " + imported.size() + " 章。");
    }

    // ---------------------- 读取 ----------------------

    public String booksJson() {
        List<String> arr = new ArrayList<>();
        for (Book b : books.values()) arr.add(b.toSummaryJson());
        return Json.arr(arr);
    }

    public String bookDetailJson(String id, Map<String, String> params) {
        Book b = requireBook(id);
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"id\":").append(Json.str(b.id));
        sb.append(",\"title\":").append(Json.str(b.title));
        sb.append(",\"author\":").append(Json.str(b.author));
        sb.append(",\"intro\":").append(Json.str(b.intro));
        sb.append(",\"cover\":").append(Json.str(b.cover));
        sb.append(",\"chapterCount\":").append(b.chapterCount);
        sb.append(",\"chapters\":").append(chaptersJson(id, params));
        sb.append("}");
        return sb.toString();
    }

    /** 某本书的章节列表，支持分页 ?offset=0&limit=50（limit 上限 200）。 */
    public String chaptersJson(String bookId, Map<String, String> params) {
        List<Chapter> list = chaptersOf(bookId);
        int total = list.size();
        int limit = parseInt(params.get("limit"), 50);
        int offset = parseInt(params.get("offset"), 0);
        if (limit > 200) limit = 200;
        if (offset < 0) offset = 0;

        StringBuilder sb = new StringBuilder();
        sb.append("{\"total\":").append(total);
        sb.append(",\"offset\":").append(offset);
        sb.append(",\"limit\":").append(limit);
        sb.append(",\"items\":[");
        int end = Math.min(offset + limit, total);
        for (int i = offset; i < end; i++) {
            if (i > offset) sb.append(',');
            sb.append(list.get(i).toListItemJson());
        }
        sb.append("]}");
        return sb.toString();
    }

    public String chapterDetailJson(String id) {
        Chapter c = chaptersById.get(id);
        if (c == null) throw new HttpError(404, "章节不存在: " + id);
        int idx = order.indexOf(c);
        String prev = (idx > 0) ? order.get(idx - 1).id : "";
        String next = (idx < order.size() - 1) ? order.get(idx + 1).id : "";
        return c.toDetailJson(prev, next);
    }

    /** 全文搜索：标题或正文包含关键字即命中，返回带摘要的结果。 */
    public String searchJson(Map<String, String> params) {
        String q = (params.get("q") == null ? "" : params.get("q")).trim();
        String bookId = params.get("bookId");
        List<String> arr = new ArrayList<>();
        if (!q.isEmpty()) {
            for (Chapter c : order) {
                if (bookId != null && !c.bookId.equals(bookId)) continue;
                boolean hit = c.title.contains(q)
                        || (c.content != null && c.content.contains(q));
                if (hit) arr.add(c.toSearchItemJson(q));
            }
        }
        return Json.arr(arr);
    }

    // ---------------------- 内部辅助 ----------------------

    private Book requireBook(String id) {
        Book b = books.get(id);
        if (b == null) throw new HttpError(404, "书籍不存在: " + id);
        return b;
    }

    private List<Chapter> chaptersOf(String bookId) {
        List<Chapter> list = new ArrayList<>();
        for (Chapter c : order) if (c.bookId.equals(bookId)) list.add(c);
        return list;
    }

    private static int parseInt(String s, int def) {
        if (s == null) return def;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }
}
