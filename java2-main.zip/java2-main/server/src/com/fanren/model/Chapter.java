package com.fanren.model;

import com.fanren.Json;

/**
 * 章节模型。content 为正文，列表接口不返回它（体积大），详情接口才返回。
 */
public class Chapter {

    public final String id;       // 全局唯一，如 "fanren-12"
    public final String bookId;   // 所属书籍 id
    public final int index;       // 第几章（从 1 开始）
    public final String title;
    public String content;        // 正文（可能很长）

    public Chapter(String id, String bookId, int index, String title, String content) {
        this.id = id;
        this.bookId = bookId;
        this.index = index;
        this.title = title;
        this.content = content;
    }

    /** 列表项 JSON：不含正文，带字数统计。 */
    public String toListItemJson() {
        return "{" +
                "\"id\":" + Json.str(id) +
                ",\"bookId\":" + Json.str(bookId) +
                ",\"index\":" + index +
                ",\"title\":" + Json.str(title) +
                ",\"wordCount\":" + (content == null ? 0 : content.length()) +
                "}";
    }

    /** 详情 JSON：含正文，并带上/下章 id，方便阅读器翻页。 */
    public String toDetailJson(String prevId, String nextId) {
        return "{" +
                "\"id\":" + Json.str(id) +
                ",\"bookId\":" + Json.str(bookId) +
                ",\"index\":" + index +
                ",\"title\":" + Json.str(title) +
                ",\"content\":" + Json.str(content) +
                ",\"wordCount\":" + (content == null ? 0 : content.length()) +
                ",\"prevId\":" + Json.str(prevId) +
                ",\"nextId\":" + Json.str(nextId) +
                "}";
    }

    /** 搜索结果项 JSON：含一段命中上下文（摘要）。 */
    public String toSearchItemJson(String query) {
        String excerpt = buildExcerpt(query);
        return "{" +
                "\"id\":" + Json.str(id) +
                ",\"bookId\":" + Json.str(bookId) +
                ",\"index\":" + index +
                ",\"title\":" + Json.str(title) +
                ",\"excerpt\":" + Json.str(excerpt) +
                "}";
    }

    /** 在正文里找到 query 第一次出现的位置，截取前后各 30 字作为摘要。 */
    private String buildExcerpt(String query) {
        if (content == null) return "";
        int at = content.indexOf(query);
        if (at < 0) {
            int len = Math.min(40, content.length());
            return content.substring(0, len) + (content.length() > len ? "…" : "");
        }
        int start = Math.max(0, at - 30);
        int end = Math.min(content.length(), at + query.length() + 30);
        String piece = content.substring(start, end);
        return (start > 0 ? "…" : "") + piece + (end < content.length() ? "…" : "");
    }
}
