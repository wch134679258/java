package com.fanren.model;

import com.fanren.Json;

/**
 * 书籍模型。本项目用途单一：只读《凡人修仙传》这一本书，
 * 但保留通用结构（id / 标题 / 作者 / 简介 / 封面），方便以后扩展其他书。
 */
public class Book {

    public final String id;
    public final String title;
    public final String author;
    public final String intro;
    public final String cover;   // 这里用 emoji 占位，真实项目可换成图片 URL
    public int chapterCount;     // 章节总数（初始化后填充）

    public Book(String id, String title, String author, String intro, String cover) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.intro = intro;
        this.cover = cover;
    }

    /** 书籍列表/详情里用的精简 JSON（不含章节内容）。 */
    public String toSummaryJson() {
        return "{" +
                "\"id\":" + Json.str(id) +
                ",\"title\":" + Json.str(title) +
                ",\"author\":" + Json.str(author) +
                ",\"intro\":" + Json.str(intro) +
                ",\"cover\":" + Json.str(cover) +
                ",\"chapterCount\":" + chapterCount +
                "}";
    }
}
