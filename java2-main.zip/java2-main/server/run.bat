@echo off
REM 编译并启动《凡人修仙传》阅读后端（纯 JDK，无需 Maven/Gradle）
if not exist out mkdir out
javac -d out src\com\fanren\*.java src\com\fanren\model\*.java src\com\fanren\store\*.java
java -Dserver.port=8080 -cp out com.fanren.Main
